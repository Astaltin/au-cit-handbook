<?php

return [
   'unauthorized' => '',

   'serverError' => 'Something went wrong.',

   'registrationFailed' => 'Failed to create account.',
   'registrationSuccess' => 'Account created successfully.',

   'loginSuccess' => 'Successfully logged in.',
   'loginFailed' => 'Authentication failed.',
   'logoutSuccess' => 'Successfully logged out.',
];
